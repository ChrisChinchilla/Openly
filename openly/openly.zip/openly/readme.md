# Openly - Open source Grammarly

This is a series of Vale style to attempt to emulate some features of the commercial, and closed source, Grammarly. More to come.
